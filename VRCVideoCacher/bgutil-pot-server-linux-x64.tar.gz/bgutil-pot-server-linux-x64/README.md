If using the provider along with yt-dlp as intended, stop reading here. The server and script will be used automatically with no intervention required.

If you are interested in using the script/server standalone for generating your own PO token, read onwards.

> [!CAUTION] 
> These endpoints and options are **unstable** and may change without notice.

# Server

## Ready-to-run packages

The **Package standalone server** GitHub Actions workflow builds separate archives
for Windows x64 and glibc Linux x64. Download its artifacts, or the archives attached
by the release workflow, and extract the entire archive. The yt-dlp plugin and
production dependencies (including native canvas) are included, but yt-dlp itself
and a JavaScript runtime are not included.
Place your existing bundled Deno executable in the extracted directory (`deno.exe`
on Windows, `deno` on Linux). No npm installation or dependency download is needed
on the destination. The packages are checked with Deno 2.9.6.

Run directly from the extracted directory; no launcher scripts are included.

Windows:

```powershell
.\deno.exe run --no-config --no-lock --node-modules-dir=manual --cached-only --allow-env --allow-net --allow-read --allow-ffi .\build\main.js --port 4416 --host 127.0.0.1
```

Linux:

```shell
./deno run --no-config --no-lock --node-modules-dir=manual --cached-only --allow-env --allow-net --allow-read --allow-ffi ./build/main.js --port 4416 --host 127.0.0.1
```

Keep the extracted directory intact. Windows and Linux packages are not interchangeable.
The Linux package is built and checked on Ubuntu 22.04; it targets glibc systems
with compatible system libraries, not Alpine/musl or older Linux distributions.
The matching yt-dlp plugin is bundled under
`yt-dlp-plugins/bgutil-ytdlp-pot-provider/yt_dlp_plugins`. Load it by passing
`--plugin-dirs "/path/to/extracted-package/yt-dlp-plugins"` to yt-dlp, or copy the
`bgutil-ytdlp-pot-provider` directory into one of your
[yt-dlp plugin folders](https://github.com/yt-dlp/yt-dlp#installing-plugins).
For example, from the extracted directory on Windows:

```powershell
yt-dlp --plugin-dirs ".\yt-dlp-plugins" VIDEO_URL
```

Keep the server running while using yt-dlp. The plugin connects to
`http://127.0.0.1:4416` by default; for a different address, also pass
`--extractor-args "youtubepot-bgutilhttp:base_url=http://127.0.0.1:8080"`.

### Building packages

On each target OS/architecture, install Node.js 24 or newer and make Deno available
on PATH for verification, then run from `server`:

```shell
npm ci
npm run package:server
```

If Deno is not on PATH, pass its executable path, for example on Windows:

```powershell
npm run package:server -- ..\out\deno.exe
```

The builder writes `dist/bgutil-pot-server-win-x64` or
`dist/bgutil-pot-server-linux-x64` at the repository root, replacing the previous
generated directory for that target. It uses the lockfile, compiles the existing
TypeScript server, copies the plugin without Python bytecode caches, installs
production dependencies in isolation, and smoke-tests
with Deno outside the repository using an empty cache and offline module loading.
Node.js is a build tool only and is not distributed. Build-time internet access
is required to install dependencies.
Re-run `npm run package:server` to rebuild; no installation is needed on the
destination. GitHub Actions builds and checks both targets and archives the results.
The commands above use Deno's manual node_modules mode and cached-only module loading,
so they do not install dependencies at startup. Normal token generation still needs
network access.

**Options**

- `-p, --port <PORT>`: The port on which the server listens.
- `-H, --host <HOST>`: Host/IP to listen on. Repeat it or separate values with commas to bind multiple addresses. Defaults to localhost only (`127.0.0.1` and `::1`).

**Endpoints**

- **POST /get_pot**: Generate a new POT.
    - The request data should be a JSON including:
        - `content_binding`: [Content binding](#content-binding) (optional, set to visitor data in `innertube_context` or a freshly generated visitor data if null).
        - `proxy`: A string indicating the proxy to use for the requests (optional).
        - `bypass_cache`: boolean, when set to true, bypasses any cache if present (optional).
        - `challenge`: string or null, the BotGuard challenge from Innertube (optional).
        - `disable_tls_verification`: boolean, when set to true, disables TLS certificate verification. (optional)
        - `innertube_context`: object, the innertube context to be sent in the innertube request in case `challenge` is not present. Note that when available, the public IP in the innertube context is used as the cache key for POTs. (optional)
        - `source_address`: string, the cient-side IP address to bind to. (optional)
    - Returns a JSON:
        - `poToken`: The POT.
        - `contentBinding`: The generated or passed [content binding](#content-binding).
        - `expiresAt`: The expiry timestamp of the POT entry.
- **GET /ping**: Ping the server. The response includes:
    - `server_uptime`: Uptime of the server process in seconds.
    - `version`: Current server version.

# Script Method

**Options**

- `-c, --content-binding <content-binding>`: The [content binding](#content-binding), optional.
- `-p, --proxy <proxy-all>`: The proxy to use for the requests, optional.
- `-b, --bypass-cache`: See `bypass_cache` from the `POST /get_pot` endpoint.
- `-s, --source-address <source-address>`: See `source_address` from the `POST /get_pot` endpoint, optional.
- `--innertube-context <innertube-context>`: See `innertube_context` from the `POST /get_pot` endpoint, optional.
- `--disable-tls-verification`: See `disable_tls_verification` from the above endpoint.
- `--version`: Print the script version and exit.
- `--verbose`: Use verbose logging.

**Environment Variables**

- **TOKEN_TTL**: The time in hours for a PO token to be considered valid. While there are no definitive answers on how long a token is valid, it has been observed to be valid for at least a couple of days (Default: 6).

### Content Binding

Content bindings refer to the data used to generate a PO Token.

GVS WEBPO tokens (See [PO Tokens for GVS](https://github.com/yt-dlp/yt-dlp/wiki/PO-Token-Guide#po-tokens-for-gvs) from the PO Token Guide) used to be session-bound so the content binding for a GVS token is either a Visitor ID (also known as `visitorData`, `VISITOR_INFO1_LIVE`, used when not logged in) or the account Session ID (first part of the Data Sync ID, used when logged in). They are mostly bound to video ID now.

Player tokens are mostly content-bound and their content bindings are the video IDs. Note that the `web_music` client uses the session token instead of video ID to generate player tokens.
